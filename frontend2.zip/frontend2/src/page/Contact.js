import React from "react";

const Contact = () => {
  return (
    <div className="p-6 bg-gray-100">
      <div className="max-w-4xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h1 className="text-5xl font-bold text-center mb-8 text-red-600">
          Contact Us
        </h1>
        <p className="text-lg text-gray-700 text-center mb-10">
          We'd love to hear from you! Whether you have a question about our services, need assistance, or just want to talk food, feel free to get in touch with us.
        </p>

        <div className="space-y-6 text-center">
          <div>
            <h2 className="text-3xl font-semibold text-red-600">Email</h2>
            <p className="text-lg text-gray-700">contact@deliciouslydelivered.com</p>
          </div>

          <div>
            <h2 className="text-3xl font-semibold text-red-600">Phone</h2>
            <p className="text-lg text-gray-700">+123 456 7890</p>
          </div>

          <div>
            <h2 className="text-3xl font-semibold text-red-600">Location</h2>
            <p className="text-lg text-gray-700">123 Food Street, Flavor Town, FT 12345</p>
          </div>
        </div>

        <div className="mt-10 text-center">
          <h2 className="text-3xl font-semibold text-red-600">Working Hours</h2>
          <p className="text-lg text-gray-700">Monday - Friday: 9 AM - 6 PM</p>
          <p className="text-lg text-gray-700">Saturday: 10 AM - 4 PM</p>
          <p className="text-lg text-gray-700">Sunday: Closed</p>
        </div>
      </div>
    </div>
  );
};

export default Contact;
