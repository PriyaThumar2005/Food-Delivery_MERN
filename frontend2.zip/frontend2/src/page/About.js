import React from "react";

const About = () => {
  return (
    <div className="p-6 bg-gray-100">
      <div className="max-w-5xl mx-auto bg-white p-8 rounded-lg shadow-lg">
        <h1 className="text-5xl font-bold text-center mb-8 text-red-600">
          About Us
        </h1>
        <p className="text-lg text-gray-700 mb-6 text-center">
          At <span className="font-semibold text-red-500">Deliciously Delivered</span>, we bring the world of flavors right to your doorstep. Our goal is simple: to provide a fast, easy, and delicious way to enjoy your favorite meals without leaving the comfort of your home.
        </p>
        <div className="flex flex-col md:flex-row items-center justify-between mb-10">
          <img
            src="https://www.tasteofhome.com/wp-content/uploads/2019/01/bright-red-restaurant.jpg"
            alt="Delivery Illustration"
            className="rounded-lg shadow-lg mb-6 md:mb-0 md:w-1/2"
          />
          <div className="md:w-1/2 md:ml-8">
            <h2 className="text-3xl font-semibold text-red-600 mb-4">
              Our Story
            </h2>
            <p className="text-gray-700 mb-4">
              Founded in 2024, we started with a passion for great food and a commitment to connect local restaurants with customers craving diverse, high-quality meals. Today, we continue to expand our menu, offering dishes from around the globe.
            </p>
            <p className="text-gray-700">
              Our service is more than just food delivery—it's a gateway to enjoying unforgettable culinary experiences with a single click.
            </p>
          </div>
        </div>

        <div className="bg-red-50 p-6 rounded-lg shadow-md text-center">
          <h2 className="text-3xl font-semibold text-red-600 mb-4">
            Why Choose Us?
          </h2>
          <p className="text-gray-700 mb-4">
            Fast deliveries, fresh ingredients, and unbeatable customer service are just a few reasons to choose us. Our user-friendly platform and a wide selection of restaurants make it easier than ever to satisfy your cravings.
          </p>
          <p className="text-gray-700">
            From breakfast to late-night snacks, we’re here to bring the best food experiences right to your door.
          </p>
        </div>

        <div className="text-center mt-10">
          <h2 className="text-3xl font-semibold text-red-600 mb-6">
            Join Our Community
          </h2>
          <p className="text-gray-700 mb-4">
            Whether you're a foodie, a restaurant owner, or just someone who loves great service, we welcome you to join us in redefining how food is delivered.
          </p>
          <p className="text-gray-700">
            Let's eat, explore, and enjoy together!
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;
