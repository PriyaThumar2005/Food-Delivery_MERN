const express=require("express")
const cors=require("cors")
const mongoose=require("mongoose")
const dotenv=require("dotenv").config()

const app=express()
app.use(cors())
// app.use(express.json({limit :"10mb"}))
app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ limit: "15mb", extended: true }));




const PORT=process.env.PORT || 8080
//mongodb connection
console.log(process.env.MONGODB_URL)
mongoose.set('strictQuery',false);

mongoose.connect(process.env.MONGODB_URL)
.then(()=>console.log("Connect to database"))
.catch((err)=>console.log(err))

//schema
const userSchema = mongoose.Schema({
    firstName:String,
        lastName:String,
        email:{
            type : String,
            unique: true
        },
        password:String,
        confirmpassword:String,
        image:String,
})

//model
const userModel=mongoose.model("user",userSchema)

//api

app.get("/",(req,res)=>{
    res.send("Server is running")
})

// app.post("/signup",(req,res)=>{
//     console.log(req.body)
//     const {email} =req.body

//     userModel.findOne({email:email},(err,result)=>{
//         console.log(result)
//         console.log(err)
//     })

// })
//api sign up
app.post("/signup", async (req, res) => {
    try {
        const { email } = req.body;

        if (!email) {
            return res.status(400).json({ message: "Email is required", alert: false });
        }

        const result = await userModel.findOne({ email: email });
        console.log("Database query result:", result);

        if (result) {
            res.status(409).json({ message: "User already exists", alert: false });
        } else {
            const data = new userModel(req.body);
            await data.save();
            res.status(201).json({ message: "Successfully signed up", alert: true });
        }
    } catch (err) {
        console.error("Error during signup:", err);
        res.status(500).json({ message: "Internal server error" });
    }
});


//api login
app.post("/login", async (req, res) => {
    try {
        console.log(req.body);
        const { email } = req.body;

        // Use async/await to handle the asynchronous operation
        const result = await userModel.findOne({ email: email });

        if (result) {
            
            const dataSend = {
                _id: result._id,
                firstName: result.firstName,
                lastName: result.lastName,
                email: result.email,
                image: result.image,
            };
            console.log(dataSend)
            res.send({ message: "Login is successfully done", alert: true, data: dataSend });
        } else {
            res.send({ message: "User not found", alert: false });
        }
    } catch (err) {
        console.error(err);
        res.status(500).send({ message: "An error occurred during login", alert: false });
    }
});

//product section

const schemaProduct=mongoose.Schema({
    name :String,
    category :String,
    image :String,
    price:String,
    description:String,
});
const productModel = mongoose.model("product",schemaProduct)


//save product in database 
//api


app.post("/uploadProduct", async (req, res) => {
    try {
        console.log("Request Body:", req.body); // Log request data
        const data = new productModel(req.body);
        const dataSave = await data.save();
        res.send({ message: "Upload successfully" });
    } catch (err) {
        console.error("Error saving product:", err);
        res.status(500).send({ message: "Failed to upload product", error: err });
    }
});

//
app.get("/product",async(req,res)=>{
    const data =await productModel.find({})
    res.send(JSON.stringify(data))
})










app.listen(PORT,()=>
    console.log("Server is running at port :"+PORT)
)